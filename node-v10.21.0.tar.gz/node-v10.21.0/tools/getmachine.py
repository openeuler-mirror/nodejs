from __future__ import print_function
import platform
print(platform.machine())
