#! }]) // isn't js
// Flags: --experimental-modules
import '../common';

const isJs = true;
export default isJs;
