// Flags: --experimental-modules
import '../common';
import('./test-esm-cyclic-dynamic-import');
