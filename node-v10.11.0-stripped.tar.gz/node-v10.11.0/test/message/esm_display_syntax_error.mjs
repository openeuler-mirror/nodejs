// Flags:  --experimental-modules
'use strict';
await async () => 0;
