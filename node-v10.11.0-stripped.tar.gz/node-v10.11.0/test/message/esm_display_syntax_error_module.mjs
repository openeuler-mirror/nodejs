// Flags:  --experimental-modules
import '../common';
import '../fixtures/es-module-loaders/syntax-error';
