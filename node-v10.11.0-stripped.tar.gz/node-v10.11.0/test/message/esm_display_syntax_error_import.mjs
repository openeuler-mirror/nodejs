// Flags:  --experimental-modules
/* eslint-disable no-unused-vars */
import '../common';
import {
  foo,
  notfound
} from '../fixtures/es-module-loaders/module-named-exports';
