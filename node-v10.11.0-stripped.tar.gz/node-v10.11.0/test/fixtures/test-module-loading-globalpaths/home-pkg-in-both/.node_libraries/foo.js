exports.string = '$HOME/.node_libraries';
