exports.string = '$NODE_PATH';
