'use strict';
console.log(require('foo').string);
