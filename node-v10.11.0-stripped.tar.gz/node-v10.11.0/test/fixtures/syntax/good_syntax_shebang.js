#!/usr/bin/env node
var foo = 'bar';
