'use strict'; const ässört = require('assert'); ässört(true); ässört.ok(''); ässört(null);
// aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa(false);
