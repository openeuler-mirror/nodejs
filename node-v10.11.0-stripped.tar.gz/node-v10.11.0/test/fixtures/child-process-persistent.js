setInterval(function() {}, 9999);
