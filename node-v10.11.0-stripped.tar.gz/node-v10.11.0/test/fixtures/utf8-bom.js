﻿module.exports = 42;
