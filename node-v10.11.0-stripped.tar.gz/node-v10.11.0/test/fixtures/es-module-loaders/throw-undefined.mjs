'use strict';

throw undefined;
