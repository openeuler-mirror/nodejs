'use strict';
await async () => 0;
