setTimeout(function() {
  throw new Error('timeout');
}, 10);
