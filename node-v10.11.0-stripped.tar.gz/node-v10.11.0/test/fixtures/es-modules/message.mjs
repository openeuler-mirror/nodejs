export const message = 'A message';
