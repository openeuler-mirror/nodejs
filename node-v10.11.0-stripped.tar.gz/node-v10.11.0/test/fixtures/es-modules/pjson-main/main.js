module.exports = 'main';
