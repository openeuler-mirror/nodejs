'use strict';

// Set root member
let foo = true;
foo = false;

// Return outside of function
if (!foo) {
  return;
}
