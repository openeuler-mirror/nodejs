throw {
  toString: function() {
    throw this;
  }
};
