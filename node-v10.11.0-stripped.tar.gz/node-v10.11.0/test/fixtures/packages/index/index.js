exports.ok = 'ok';
